*NOTE* This is located in my home directory, not in /var/www/html. *NOTE*
During this lab, this was the first time we had been working with node stuff in an assignment on our own.
This led to a little bit of trouble for me, as I found it difficult to get my site functional.
This is also the first lab of the semester so I am a little bit rusty, but I am going to work to get this to be functional in future versions of the labs working with my API.